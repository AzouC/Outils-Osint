# modules/web/__init__.py
"""
Modules de recherche web et dark web
"""

from .darkweb import DarkWebSearch
from .shodan_intel import ShodanIntel
from .wayback import WaybackMachine
from .domain_intel import DomainIntel

__all__ = [
    'DarkWebSearch',
    'ShodanIntel',
    'WaybackMachine',
    'DomainIntel'
]